// Renders music videos from the studio, frame-exact, with the demo track as the soundtrack.
// node tools/render-videos.js <outDir> [seconds] [size] [ids...]      (id "vj:1" = auto VJ mix)
// Soundtrack: the built-in demo (STYLE=down | techno), or a song of yours: AUDIO=song.mp3 (seconds 0 = whole song).
const { chromium } = require('playwright');
const fs = require('fs'), path = require('path'), { execFileSync } = require('child_process');
const [outDir, secArg, sizeArg, ...ids] = process.argv.slice(2);
const SEC = +(secArg || 30), SIZE = +(sizeArg || 720), FPS = 30;
const JOBS = ids.length ? ids : ['box'];
(async () => {
  fs.mkdirSync(outDir, { recursive: true });
  const b = await chromium.launch({ args: ['--use-gl=swiftshader', '--enable-unsafe-swiftshader'] });
  const pg = await b.newPage({ viewport: { width: SIZE, height: SIZE }, deviceScaleFactor: 1 });
  pg.on('pageerror', e => console.error('page:', e.message));
  await pg.goto('file://' + path.resolve(__dirname, '..', 'kaleidoscope-studio.html'));
  await pg.waitForTimeout(800);
  const STYLE = process.env.STYLE || 'down', AUDIO = process.env.AUDIO;
  let wav, track = null, secs = SEC;
  if (AUDIO) {
    const js = path.join(outDir, '.track.json');
    execFileSync('python3', [path.join(__dirname, 'analyze-audio.py'), AUDIO, js, String(FPS)], { stdio: 'inherit' });
    track = JSON.parse(fs.readFileSync(js, 'utf8')); fs.rmSync(js);
    secs = SEC ? Math.min(SEC, track.duration) : track.duration; wav = AUDIO;
  } else {
    wav = path.join(outDir, `demo-${STYLE === 'techno' ? 'techno-128' : 'downtempo-90'}bpm.wav`);
    if (!fs.existsSync(wav)) fs.writeFileSync(wav, Buffer.from(await pg.evaluate(([s, st]) => KS.audio(s, st), [SEC, STYLE]), 'base64'));
  }
  for (const job of JOBS) {
    const [id, vj] = job.split(':');
    const tmp = fs.mkdtempSync(path.join(outDir, '.f-'));
    await pg.evaluate(([id, vj, track, style]) => KS.setup(vj ? null : id, Object.assign(vj ? { vj: true, vjBars: 4 } : {}, { track, style })), [id, vj, track, STYLE]);
    const t0 = Date.now();
    for (let f = 0; f < Math.round(secs * FPS); f++) {
      const url = await pg.evaluate(dt => KS.frame(dt), 1 / FPS);
      fs.writeFileSync(path.join(tmp, String(f).padStart(5, '0') + '.jpg'), Buffer.from(url.split(',')[1], 'base64'));
    }
    const tag = AUDIO ? path.basename(AUDIO).replace(/\.[^.]+$/, '') + '-' : '';
    const name = path.join(outDir, `kaleidoscope-${tag}${vj ? 'vj-mix' : id}.mp4`);
    execFileSync('ffmpeg', ['-y', '-loglevel', 'error', '-framerate', String(FPS), '-i', path.join(tmp, '%05d.jpg'), '-i', wav,
      '-c:v', 'libx264', '-preset', 'slow', '-crf', '25', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k', '-t', String(secs), '-movflags', '+faststart', name]);
    fs.rmSync(tmp, { recursive: true });
    console.log(name, ((Date.now() - t0) / 1000).toFixed(0) + 's');
  }
  await b.close();
})();
