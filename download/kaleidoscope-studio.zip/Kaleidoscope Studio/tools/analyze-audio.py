#!/usr/bin/env python3
"""Analyse a song for frame-exact video rendering: per-frame kick / bass / mid / high, onsets, tempo, beat grid and drops.
usage: python3 tools/analyze-audio.py song.mp3 out.json [fps]
Needs ffmpeg and numpy. The output drives tools/render-videos.js (AUDIO=song.mp3)."""
import json, subprocess, sys
import numpy as np

src, out = sys.argv[1], sys.argv[2]
fps = int(sys.argv[3]) if len(sys.argv) > 3 else 30
SR = 22050
raw = subprocess.run(["ffmpeg", "-v", "error", "-i", src, "-ac", "1", "-ar", str(SR), "-f", "f32le", "-"], capture_output=True, check=True).stdout
x = np.frombuffer(raw, dtype=np.float32)
dur = len(x) / SR
hop, N = SR / fps, 2048
n = int(dur * fps)
win = np.hanning(N)
freqs = np.fft.rfftfreq(N, 1 / SR)
pad = np.concatenate([np.zeros(N // 2, np.float32), x, np.zeros(N, np.float32)])
mags = np.empty((n, len(freqs)), np.float32)
for i in range(n):
    s = int(round(i * hop))
    mags[i] = np.abs(np.fft.rfft(pad[s:s + N] * win))

def band(a, b):
    m = (freqs >= a) & (freqs < b)
    return np.log1p(mags[:, m].mean(axis=1) * 10)

def norm(v, lo=20, hi=99):
    a, b = np.percentile(v, lo), np.percentile(v, hi)
    return np.clip((v - a) / max(b - a, 1e-6), 0, 1)

def env(v, att=.6, rel=.12):
    o, y = np.empty_like(v), 0.0
    for i, t in enumerate(v):
        y += (t - y) * (att if t > y else rel)
        o[i] = y
    return o

kick_r, bass_r, mid_r, high_r = band(35, 110), band(110, 260), band(260, 2200), band(2200, 10000)
bands = [env(norm(kick_r), .8, .18), env(norm(bass_r), .5, .1), env(norm(mid_r), .4, .08), env(norm(high_r), .7, .2)]

# onset strength: positive spectral flux, low end weighted
logm = np.log1p(mags * 10)
flux = np.maximum(np.diff(logm, axis=0, prepend=logm[:1]), 0)
low = freqs < 200
onset = flux[:, low].sum(axis=1) * 2 + flux[:, ~low].sum(axis=1) * .5
onset = onset - np.convolve(onset, np.ones(fps) / fps, mode="same")
onset = np.maximum(onset, 0); onset /= onset.max() + 1e-9
kflux = np.maximum(np.diff(kick_r, prepend=kick_r[:1]), 0); kflux /= kflux.max() + 1e-9
kicks = [i for i in range(1, n - 1) if kflux[i] > .25 and kflux[i] >= kflux[i - 1] and kflux[i] >= kflux[i + 1] and bands[0][i] > .35]
kk, last = [], -99
for i in kicks:
    if i - last >= fps * .2: kk.append(i); last = i

# tempo: autocorrelation of onset strength, 60-160 BPM, gently preferring 70-110 (downtempo)
ac = np.correlate(onset, onset, mode="full")[n - 1:]
best, bpm = -1, 90.0
for b in np.arange(60, 160, .25):
    lag = fps * 60 / b
    l0 = int(lag); fr = lag - l0
    if l0 + 1 >= len(ac): continue
    v = ac[l0] * (1 - fr) + ac[l0 + 1] * fr
    l2 = 2 * lag; v2 = ac[int(l2)] if int(l2) < len(ac) else 0
    score = (v + .5 * v2) * np.exp(-.5 * ((np.log2(b / 90)) / .6) ** 2)
    if score > best: best, bpm = score, float(b)
period = fps * 60 / bpm
# beat grid: best phase, then each beat may slide 2 frames toward a strong onset
phases = [(sum(onset[int(p + k * period)] for k in range(int((n - p) / period))), p) for p in np.arange(0, period, .5)]
p0 = max(phases)[1]
beats, t = [], p0
while t < n:
    i = int(round(t)); lo, hi = max(0, i - 2), min(n, i + 3)
    j = lo + int(np.argmax(onset[lo:hi])) if hi > lo else i
    beats.append(j / fps); t = j + period

# drops: loud sections that follow a quieter stretch
energy = np.convolve(bands[0] + bands[1], np.ones(fps) / fps, mode="same")
longe = np.convolve(energy, np.ones(fps * 6) / (fps * 6), mode="same")
drops, lastd = [], -1e9
for i in range(fps * 4, n):
    before = energy[i - fps * 4:i - fps].mean()
    if energy[i] > .55 * (energy.max()) and before < .45 * energy[i] and i - lastd > fps * 20:
        b = min(beats, key=lambda bt: abs(bt - i / fps)); drops.append(b); lastd = i
kickset = set(kk)
frames = [[round(float(bands[0][i]), 3), round(float(bands[1][i]), 3), round(float(bands[2][i]), 3), round(float(bands[3][i]), 3), 1 if i in kickset else 0] for i in range(n)]
json.dump({"fps": fps, "duration": dur, "bpm": round(bpm, 2), "beats": [round(b, 3) for b in beats], "drops": drops, "frames": frames}, open(out, "w"))
print(f"{src}: {dur:.1f}s, {bpm:.1f} BPM, {len(beats)} beats, {len(kk)} kicks, drops at {[round(d, 1) for d in drops]}")
